package productos;

import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre del producto:");
        double precio = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el precio del producto:"));
        int respuestaIVA = JOptionPane.showConfirmDialog(null, "¿El producto tiene IVA?", "IVA", JOptionPane.YES_NO_OPTION);
        boolean tieneIVA = (respuestaIVA == JOptionPane.YES_OPTION);

        Producto producto = new Producto(nombre, precio, tieneIVA);

        JOptionPane.showMessageDialog(null, producto.toString(), "Información del Producto", JOptionPane.INFORMATION_MESSAGE);
    }
}
